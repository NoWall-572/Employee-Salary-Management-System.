/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Staff/mainwindow.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSMainWindowENDCLASS = QtMocHelpers::stringData(
    "MainWindow",
    "showmain",
    "",
    "on_actionwrite_in_triggered",
    "on_actionread_out_triggered",
    "on_actionAddStaff_triggered",
    "on_ShowInfotableView_changed",
    "on_table_clicked",
    "QModelIndex",
    "index",
    "on_actionfind_triggered",
    "onGetMousePos",
    "pos",
    "onMenuAction",
    "QAction*",
    "act",
    "on_actionreturn_triggered",
    "on_actionsort_triggered"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {
    uint offsetsAndSizes[36];
    char stringdata0[11];
    char stringdata1[9];
    char stringdata2[1];
    char stringdata3[28];
    char stringdata4[28];
    char stringdata5[28];
    char stringdata6[29];
    char stringdata7[17];
    char stringdata8[12];
    char stringdata9[6];
    char stringdata10[24];
    char stringdata11[14];
    char stringdata12[4];
    char stringdata13[13];
    char stringdata14[9];
    char stringdata15[4];
    char stringdata16[26];
    char stringdata17[24];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSMainWindowENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSMainWindowENDCLASS_t qt_meta_stringdata_CLASSMainWindowENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 8),  // "showmain"
        QT_MOC_LITERAL(20, 0),  // ""
        QT_MOC_LITERAL(21, 27),  // "on_actionwrite_in_triggered"
        QT_MOC_LITERAL(49, 27),  // "on_actionread_out_triggered"
        QT_MOC_LITERAL(77, 27),  // "on_actionAddStaff_triggered"
        QT_MOC_LITERAL(105, 28),  // "on_ShowInfotableView_changed"
        QT_MOC_LITERAL(134, 16),  // "on_table_clicked"
        QT_MOC_LITERAL(151, 11),  // "QModelIndex"
        QT_MOC_LITERAL(163, 5),  // "index"
        QT_MOC_LITERAL(169, 23),  // "on_actionfind_triggered"
        QT_MOC_LITERAL(193, 13),  // "onGetMousePos"
        QT_MOC_LITERAL(207, 3),  // "pos"
        QT_MOC_LITERAL(211, 12),  // "onMenuAction"
        QT_MOC_LITERAL(224, 8),  // "QAction*"
        QT_MOC_LITERAL(233, 3),  // "act"
        QT_MOC_LITERAL(237, 25),  // "on_actionreturn_triggered"
        QT_MOC_LITERAL(263, 23)   // "on_actionsort_triggered"
    },
    "MainWindow",
    "showmain",
    "",
    "on_actionwrite_in_triggered",
    "on_actionread_out_triggered",
    "on_actionAddStaff_triggered",
    "on_ShowInfotableView_changed",
    "on_table_clicked",
    "QModelIndex",
    "index",
    "on_actionfind_triggered",
    "onGetMousePos",
    "pos",
    "onMenuAction",
    "QAction*",
    "act",
    "on_actionreturn_triggered",
    "on_actionsort_triggered"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSMainWindowENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   80,    2, 0x06,    1 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       3,    0,   81,    2, 0x08,    2 /* Private */,
       4,    0,   82,    2, 0x08,    3 /* Private */,
       5,    0,   83,    2, 0x08,    4 /* Private */,
       6,    0,   84,    2, 0x08,    5 /* Private */,
       7,    1,   85,    2, 0x08,    6 /* Private */,
      10,    0,   88,    2, 0x08,    8 /* Private */,
      11,    1,   89,    2, 0x08,    9 /* Private */,
      13,    1,   92,    2, 0x08,   11 /* Private */,
      16,    0,   95,    2, 0x08,   13 /* Private */,
      17,    0,   96,    2, 0x08,   14 /* Private */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 8,    9,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,   12,
    QMetaType::Void, 0x80000000 | 14,   15,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSMainWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSMainWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSMainWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'showmain'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionwrite_in_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionread_out_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionAddStaff_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_ShowInfotableView_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_table_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>,
        // method 'on_actionfind_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onGetMousePos'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPoint, std::false_type>,
        // method 'onMenuAction'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QAction *, std::false_type>,
        // method 'on_actionreturn_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionsort_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->showmain(); break;
        case 1: _t->on_actionwrite_in_triggered(); break;
        case 2: _t->on_actionread_out_triggered(); break;
        case 3: _t->on_actionAddStaff_triggered(); break;
        case 4: _t->on_ShowInfotableView_changed(); break;
        case 5: _t->on_table_clicked((*reinterpret_cast< std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 6: _t->on_actionfind_triggered(); break;
        case 7: _t->onGetMousePos((*reinterpret_cast< std::add_pointer_t<QPoint>>(_a[1]))); break;
        case 8: _t->onMenuAction((*reinterpret_cast< std::add_pointer_t<QAction*>>(_a[1]))); break;
        case 9: _t->on_actionreturn_triggered(); break;
        case 10: _t->on_actionsort_triggered(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 8:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QAction* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MainWindow::*)();
            if (_t _q_method = &MainWindow::showmain; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSMainWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::showmain()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP

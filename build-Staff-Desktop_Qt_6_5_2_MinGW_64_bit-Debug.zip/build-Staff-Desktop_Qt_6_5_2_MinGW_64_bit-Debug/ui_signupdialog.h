/********************************************************************************
** Form generated from reading UI file 'signupdialog.ui'
**
** Created by: Qt User Interface Compiler version 6.5.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SIGNUPDIALOG_H
#define UI_SIGNUPDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAbstractButton>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>

QT_BEGIN_NAMESPACE

class Ui_signupdialog
{
public:
    QFormLayout *formLayout;
    QLabel *label;
    QLineEdit *lineEdit_num;
    QLabel *label_2;
    QLineEdit *lineEdit_name;
    QLabel *label_3;
    QLineEdit *lineEdit_age;
    QLabel *label_4;
    QDateEdit *dateEdit_date;
    QLabel *label_5;
    QLineEdit *lineEdit_tele;
    QLabel *label_6;
    QLineEdit *lineEdit_addr;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *signupdialog)
    {
        if (signupdialog->objectName().isEmpty())
            signupdialog->setObjectName("signupdialog");
        signupdialog->resize(276, 348);
        formLayout = new QFormLayout(signupdialog);
        formLayout->setObjectName("formLayout");
        label = new QLabel(signupdialog);
        label->setObjectName("label");

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        lineEdit_num = new QLineEdit(signupdialog);
        lineEdit_num->setObjectName("lineEdit_num");

        formLayout->setWidget(0, QFormLayout::FieldRole, lineEdit_num);

        label_2 = new QLabel(signupdialog);
        label_2->setObjectName("label_2");

        formLayout->setWidget(1, QFormLayout::LabelRole, label_2);

        lineEdit_name = new QLineEdit(signupdialog);
        lineEdit_name->setObjectName("lineEdit_name");

        formLayout->setWidget(1, QFormLayout::FieldRole, lineEdit_name);

        label_3 = new QLabel(signupdialog);
        label_3->setObjectName("label_3");

        formLayout->setWidget(2, QFormLayout::LabelRole, label_3);

        lineEdit_age = new QLineEdit(signupdialog);
        lineEdit_age->setObjectName("lineEdit_age");

        formLayout->setWidget(2, QFormLayout::FieldRole, lineEdit_age);

        label_4 = new QLabel(signupdialog);
        label_4->setObjectName("label_4");

        formLayout->setWidget(3, QFormLayout::LabelRole, label_4);

        dateEdit_date = new QDateEdit(signupdialog);
        dateEdit_date->setObjectName("dateEdit_date");

        formLayout->setWidget(3, QFormLayout::FieldRole, dateEdit_date);

        label_5 = new QLabel(signupdialog);
        label_5->setObjectName("label_5");

        formLayout->setWidget(4, QFormLayout::LabelRole, label_5);

        lineEdit_tele = new QLineEdit(signupdialog);
        lineEdit_tele->setObjectName("lineEdit_tele");

        formLayout->setWidget(4, QFormLayout::FieldRole, lineEdit_tele);

        label_6 = new QLabel(signupdialog);
        label_6->setObjectName("label_6");

        formLayout->setWidget(5, QFormLayout::LabelRole, label_6);

        lineEdit_addr = new QLineEdit(signupdialog);
        lineEdit_addr->setObjectName("lineEdit_addr");

        formLayout->setWidget(5, QFormLayout::FieldRole, lineEdit_addr);

        buttonBox = new QDialogButtonBox(signupdialog);
        buttonBox->setObjectName("buttonBox");
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        formLayout->setWidget(6, QFormLayout::FieldRole, buttonBox);


        retranslateUi(signupdialog);
        QObject::connect(buttonBox, &QDialogButtonBox::accepted, signupdialog, qOverload<>(&QDialog::accept));
        QObject::connect(buttonBox, &QDialogButtonBox::rejected, signupdialog, qOverload<>(&QDialog::reject));

        QMetaObject::connectSlotsByName(signupdialog);
    } // setupUi

    void retranslateUi(QDialog *signupdialog)
    {
        signupdialog->setWindowTitle(QCoreApplication::translate("signupdialog", "\350\201\214\345\267\245\344\277\241\346\201\257\347\231\273\350\256\260\350\241\250", nullptr));
        label->setText(QCoreApplication::translate("signupdialog", "\345\267\245     \345\217\267\357\274\232", nullptr));
        label_2->setText(QCoreApplication::translate("signupdialog", "\345\247\223     \345\220\215\357\274\232", nullptr));
        label_3->setText(QCoreApplication::translate("signupdialog", "\345\271\264     \351\276\204\357\274\232", nullptr));
        label_4->setText(QCoreApplication::translate("signupdialog", "\345\205\245\350\201\214\346\227\245\346\234\237\357\274\232", nullptr));
        label_5->setText(QCoreApplication::translate("signupdialog", "\347\224\265    \350\257\235\357\274\232", nullptr));
        label_6->setText(QCoreApplication::translate("signupdialog", "\344\275\217    \345\235\200\357\274\232", nullptr));
    } // retranslateUi

};

namespace Ui {
    class signupdialog: public Ui_signupdialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SIGNUPDIALOG_H

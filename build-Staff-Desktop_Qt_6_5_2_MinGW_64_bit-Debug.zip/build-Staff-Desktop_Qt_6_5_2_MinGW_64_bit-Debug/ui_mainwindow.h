/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.5.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionwrite_in;
    QAction *actionread_out;
    QAction *actionAddStaff;
    QAction *actionfind;
    QAction *actionreturn;
    QAction *actionsort;
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QTableView *ShowInfotableView;
    QMenuBar *menubar;
    QMenu *menu;
    QMenu *menu_2;
    QMenu *menu_3;
    QStatusBar *statusbar;
    QToolBar *toolBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(800, 600);
        actionwrite_in = new QAction(MainWindow);
        actionwrite_in->setObjectName("actionwrite_in");
        actionread_out = new QAction(MainWindow);
        actionread_out->setObjectName("actionread_out");
        actionAddStaff = new QAction(MainWindow);
        actionAddStaff->setObjectName("actionAddStaff");
        actionfind = new QAction(MainWindow);
        actionfind->setObjectName("actionfind");
        actionreturn = new QAction(MainWindow);
        actionreturn->setObjectName("actionreturn");
        actionsort = new QAction(MainWindow);
        actionsort->setObjectName("actionsort");
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setObjectName("verticalLayout");
        ShowInfotableView = new QTableView(centralwidget);
        ShowInfotableView->setObjectName("ShowInfotableView");

        verticalLayout->addWidget(ShowInfotableView);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 800, 21));
        menu = new QMenu(menubar);
        menu->setObjectName("menu");
        menu_2 = new QMenu(menubar);
        menu_2->setObjectName("menu_2");
        menu_3 = new QMenu(menubar);
        menu_3->setObjectName("menu_3");
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);
        toolBar = new QToolBar(MainWindow);
        toolBar->setObjectName("toolBar");
        MainWindow->addToolBar(Qt::TopToolBarArea, toolBar);

        menubar->addAction(menu->menuAction());
        menubar->addAction(menu_2->menuAction());
        menubar->addAction(menu_3->menuAction());
        menu->addAction(actionwrite_in);
        menu->addAction(actionread_out);
        menu_2->addAction(actionAddStaff);
        menu_3->addAction(actionfind);
        menu_3->addAction(actionsort);
        menu_3->addSeparator();
        menu_3->addAction(actionreturn);
        toolBar->addAction(actionreturn);
        toolBar->addSeparator();
        toolBar->addAction(actionAddStaff);
        toolBar->addAction(actionfind);
        toolBar->addAction(actionsort);
        toolBar->addSeparator();

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "\350\201\214\345\267\245\345\267\245\350\265\204\347\256\241\347\220\206\347\263\273\347\273\237", nullptr));
        actionwrite_in->setText(QCoreApplication::translate("MainWindow", "\345\255\230\345\202\250\350\201\214\345\267\245\344\277\241\346\201\257\350\241\250", nullptr));
        actionread_out->setText(QCoreApplication::translate("MainWindow", "\350\257\273\345\217\226\350\201\214\345\267\245\344\277\241\346\201\257\350\241\250", nullptr));
        actionAddStaff->setText(QCoreApplication::translate("MainWindow", "\346\267\273\345\212\240\350\201\214\345\267\245\344\277\241\346\201\257", nullptr));
        actionfind->setText(QCoreApplication::translate("MainWindow", "\346\237\245\346\211\276", nullptr));
        actionreturn->setText(QCoreApplication::translate("MainWindow", "\350\277\224\345\233\236\344\270\273\351\241\265", nullptr));
        actionsort->setText(QCoreApplication::translate("MainWindow", "\346\216\222\345\272\217", nullptr));
        menu->setTitle(QCoreApplication::translate("MainWindow", "\346\226\207\344\273\266\347\256\241\347\220\206", nullptr));
        menu_2->setTitle(QCoreApplication::translate("MainWindow", "\347\274\226\350\276\221", nullptr));
        menu_3->setTitle(QCoreApplication::translate("MainWindow", "\346\237\245\347\234\213", nullptr));
        toolBar->setWindowTitle(QCoreApplication::translate("MainWindow", "toolBar", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H

/********************************************************************************
** Form generated from reading UI file 'findstaff.ui'
**
** Created by: Qt User Interface Compiler version 6.5.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FINDSTAFF_H
#define UI_FINDSTAFF_H

#include <QtCore/QVariant>
#include <QtWidgets/QAbstractButton>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>

QT_BEGIN_NAMESPACE

class Ui_FindStaff
{
public:
    QDialogButtonBox *buttonBox;
    QLineEdit *lineEdit_find;
    QComboBox *comboBox;
    QLabel *label;

    void setupUi(QDialog *FindStaff)
    {
        if (FindStaff->objectName().isEmpty())
            FindStaff->setObjectName("FindStaff");
        FindStaff->resize(380, 325);
        buttonBox = new QDialogButtonBox(FindStaff);
        buttonBox->setObjectName("buttonBox");
        buttonBox->setGeometry(QRect(190, 220, 166, 24));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        lineEdit_find = new QLineEdit(FindStaff);
        lineEdit_find->setObjectName("lineEdit_find");
        lineEdit_find->setGeometry(QRect(227, 130, 131, 23));
        comboBox = new QComboBox(FindStaff);
        comboBox->setObjectName("comboBox");
        comboBox->setGeometry(QRect(110, 130, 111, 24));
        label = new QLabel(FindStaff);
        label->setObjectName("label");
        label->setGeometry(QRect(30, 130, 71, 21));

        retranslateUi(FindStaff);
        QObject::connect(buttonBox, &QDialogButtonBox::accepted, FindStaff, qOverload<>(&QDialog::accept));
        QObject::connect(buttonBox, &QDialogButtonBox::rejected, FindStaff, qOverload<>(&QDialog::reject));

        QMetaObject::connectSlotsByName(FindStaff);
    } // setupUi

    void retranslateUi(QDialog *FindStaff)
    {
        FindStaff->setWindowTitle(QCoreApplication::translate("FindStaff", "\346\237\245\346\211\276", nullptr));
        label->setText(QCoreApplication::translate("FindStaff", "\346\237\245 \346\211\276 \347\261\273 \345\236\213 \357\274\232", nullptr));
    } // retranslateUi

};

namespace Ui {
    class FindStaff: public Ui_FindStaff {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FINDSTAFF_H
